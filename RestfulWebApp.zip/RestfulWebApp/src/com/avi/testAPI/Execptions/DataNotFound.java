package com.avi.testAPI.Execptions;

import javassist.SerialVersionUID;

public class DataNotFound extends RuntimeException{
	private static final long serialVersionUID = -5716756592497623039L;

	public DataNotFound(String messsage){
		super(messsage);
	}

}
