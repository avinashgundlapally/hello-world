package com.avi.testAPI.Execptions;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;



import com.avi.testAPI.model.ExecptionBean;

@Provider
public class DatanotfoundExecptionMapper implements ExceptionMapper<DataNotFound> {

	@Override
	public Response toResponse(DataNotFound ex) {
		ExecptionBean eb = new  ExecptionBean(ex.getMessage(), "www.google.com", 555);
		return Response.status(Status.NOT_FOUND)
		        .entity(eb)
		        .build();                         
		 
	}

	}
