package com.avi.testAPI.Execptions;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import com.avi.testAPI.model.ExecptionBean;

public class GenericExeceptionMapper implements ExceptionMapper<Throwable>{

	@Override
	public Response toResponse(Throwable ex) {
		ExecptionBean eb = new  ExecptionBean(ex.getMessage(), "www.google.com", 535);
		return Response.status(Status.INTERNAL_SERVER_ERROR)
				.entity(eb)
				.type(MediaType.APPLICATION_JSON)
				.build();
//		return null;
	}

}
