package com.avi.testAPI;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

@Path("/myresource")
public class MyResource {

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String getit(){
		return "Got it...!";
	}
}
