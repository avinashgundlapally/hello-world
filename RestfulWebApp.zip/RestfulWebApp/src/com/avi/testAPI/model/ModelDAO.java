package com.avi.testAPI.model;

import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement
public class ModelDAO {

	private long id;
	private String messages;
	private Date createddate;
	private String Author;
	
	public ModelDAO(){
		
	}
	public ModelDAO(long id, String messages, Date createddate, String author) {
		super();
		this.id = id;
		this.messages = messages;
		this.createddate = createddate;
		this.Author = author;
	}
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getMessages() {
		return messages;
	}
	public void setMessages(String messages) {
		this.messages = messages;
	}
	public Date getCreateddate() {
		return createddate;
	}
	public void setCreateddate(Date createddate) {
		this.createddate = createddate;
	}
	public String getAuthor() {
		return Author;
	}
	public void setAuthor(String author) {
		Author = author;
	}
	
	
}
