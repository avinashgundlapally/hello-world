package com.avi.testAPI.model;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class ExecptionBean {

	private String errormessage;
	private String doclink;
	private int errorcode;
	public String getErrormessage() {
		return errormessage;
	}
	public void setErrormessage(String errormessage) {
		this.errormessage = errormessage;
	}
	public String getDoclink() {
		return doclink;
	}
	public void setDoclink(String doclink) {
		this.doclink = doclink;
	}
	public int getErrorcode() {
		return errorcode;
	}
	public void setErrorcode(int errorcode) {
		this.errorcode = errorcode;
	}
	public ExecptionBean(String errormessage, String doclink, int errorcode) {
		super();
		this.errormessage = errormessage;
		this.doclink = doclink;
		this.errorcode = errorcode;
	}
	
	public ExecptionBean(){}
}
