package com.avi.testAPI.DAO;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.avi.testAPI.Databases.DatabaseClass;
import com.avi.testAPI.model.ModelDAO;
import com.avi.testAPI.model.Profile;

public class PopulateModel {

	private Map<Long,ModelDAO> messages = DatabaseClass.getMessages();
	
	
	public PopulateModel(){
		Date dt =  new Date();
		messages.put(1L, new ModelDAO(1L, "helloo sir", dt, "Avinash"));
		messages.put(2L, new ModelDAO(2L, "helloo to you sir", dt, "Akash"));
	}
	
	public List<ModelDAO> PopulateMO() {
		List<ModelDAO> li = new ArrayList<ModelDAO>(messages.values());
		return li;
	}
	
	public ModelDAO addmessage (ModelDAO msg){
		msg.setId(messages.size()+1);
		messages.put(msg.getId(), msg);
		return msg;
	}
	
	public ModelDAO removeMsg(long id){
		return messages.remove(id);
	}
	public ModelDAO getmessage(long id){
		
		return messages.get(id);
	}
	
}
