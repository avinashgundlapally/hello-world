package com.avi.testAPI.DAO;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import com.avi.testAPI.Databases.DatabaseClass;
import com.avi.testAPI.model.Profile;

public class PopulateProf {

	private Map<String, Profile> profile = DatabaseClass.getProfile();

	public PopulateProf() {
		Date dt = new Date();
		profile.put("avigun", new Profile("avigun", 1L, "Avinash", "Akash", dt));
	}

	public List<Profile> PopulateMO() {
		List<Profile> li = new ArrayList<Profile>(profile.values());
		return li;
	}

	public Profile addmessage(Profile msg) {
		msg.setId(profile.size() + 1);
		profile.put(msg.getProfname(), msg);
		return msg;
	}

	public Profile removeMsg(long id) {
		return profile.remove(id);
	}

	public Profile getmessage(String username) {

		return profile.get(username);
	}
	
	public Profile updateprof(Profile prof) {
		
		profile.put(prof.getProfname(), prof);
		return prof;
	}
}
