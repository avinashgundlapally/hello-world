package com.avi.testAPI.messages;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.avi.testAPI.DAO.PopulateProf;
import com.avi.testAPI.model.ModelDAO;
import com.avi.testAPI.model.Profile;
@Path("/profile")
public class ProduceProfiles {

	
	PopulateProf pf =  new PopulateProf();
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List <Profile> getProfiles(){
		return pf.PopulateMO();
	}
	
	@GET
	@Path("/{profilename}")
	@Produces(MediaType.APPLICATION_JSON)
	public Profile getMsg(@PathParam("profilename") String id) {
		return pf.getmessage(id);
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Profile postmessage(Profile mesage){
		return pf.addmessage(mesage);
	}
	
	
}
