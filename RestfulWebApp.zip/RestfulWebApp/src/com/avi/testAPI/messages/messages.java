package com.avi.testAPI.messages;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response.Status;

import com.avi.testAPI.DAO.PopulateModel;
import com.avi.testAPI.Execptions.DataNotFound;
import com.avi.testAPI.model.ModelDAO;

@Path("messages")
public class messages {

	PopulateModel pp = new PopulateModel();

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<ModelDAO> getMessage() {
		List<ModelDAO> li = pp.PopulateMO();
		return li;
	}

	@GET
	@Path("/{msgID}")
	@Produces(MediaType.APPLICATION_JSON)
	public ModelDAO getMsg(@PathParam("msgID") long id) {
		ModelDAO md = pp.getmessage(id);
		if(md == null){
			throw new WebApplicationException(Status.NO_CONTENT);
		}
		return pp.getmessage(id);
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public ModelDAO postmessage(ModelDAO mesage){
		return pp.addmessage(mesage);
	}
}
