package com.avi.testAPI.Databases;

import java.util.HashMap;
import java.util.Map;

import com.avi.testAPI.model.ModelDAO;
import com.avi.testAPI.model.Profile;

public class DatabaseClass {

	private static Map<Long,ModelDAO> messages = new HashMap<>();
	private static Map<String,Profile> profile =  new HashMap<>();
	
	public static Map<Long, ModelDAO> getMessages() {
		return messages;
	}
	public static Map<String, Profile> getProfile() {
		return profile;
	}
	
	
	
}
